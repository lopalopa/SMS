<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_name = $_POST['student_name'];
    $class_id = $_POST['class_id'];
    $sql = "INSERT INTO students (name, class_id) VALUES ('$student_name', '$class_id')";
    if ($conn->query($sql) === TRUE) {
        $message = "Student added successfully!";
        $message_type = "success";
    } else {
        $message = "Error: " . $sql . "<br>" . $conn->error;
        $message_type = "error";
    }
}
?>
<?php include 'includes/header.php'; ?>
<main>
    <div class="form-container">
        <h2>Add Student</h2>
        
        <?php if (isset($message)): ?>
            <div class="message <?= $message_type; ?>"><?= $message; ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <label for="student_name">Student Name:</label>
            <input type="text" name="student_name" required>

            <label for="class_id">Class:</label>
            <select name="class_id" required>
                <option value="">Select Class</option>
                <?php
                $result = $conn->query("SELECT * FROM classes");
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
                }
                ?>
            </select>

            <button type="submit" class="btn">Add Student</button>
        </form>
    </div>
</main>
<?php include 'includes/footer.php'; ?>
