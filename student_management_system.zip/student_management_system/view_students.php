<?php include 'db.php'; ?>
<?php include 'includes/header.php'; ?>
<main>
    <div class="table-container">
        <h2>View Students</h2>
        
        <!-- Students Table -->
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Class</th>
                    <th>Created At</th>
                    <th>Actions</th> <!-- New column for actions -->
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT students.id, students.name, classes.name AS class_name, students.created_at 
                        FROM students 
                        JOIN classes ON students.class_id = classes.id";
                $result = $conn->query($sql);

                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['name']}</td>
                            <td>{$row['class_name']}</td>
                            <td>{$row['created_at']}</td>
                            <td>
                                <a href='view_student.php?id={$row['id']}' class='btn view-btn'>View</a>
                                <a href='edit_student.php?id={$row['id']}' class='btn edit-btn'>Edit</a>
                                <a href='delete_student.php?id={$row['id']}' class='btn delete-btn' onclick='return confirm(\"Are you sure you want to delete this student?\")'>Delete</a>
                            </td>
                          </tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</main>
<?php include 'includes/footer.php'; ?>
