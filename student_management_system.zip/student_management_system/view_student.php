<?php
include 'db.php';

// Check if the 'id' is provided in the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch the student's details from the database
    $sql = "SELECT students.id, students.name, students.class_id, students.created_at, classes.name AS class_name 
            FROM students 
            JOIN classes ON students.class_id = classes.id
            WHERE students.id = $id";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Fetch the student record
        $row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Details</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <!-- Student Details Section -->
        <h2 class="mb-4">Student Details</h2>
        <div class="card shadow-sm">
            <div class="card-body">
                <table class="table table-bordered table-striped">
                    <tbody>
                        <tr>
                            <th>ID</th>
                            <td><?php echo $row['id']; ?></td>
                        </tr>
                        <tr>
                            <th>Name</th>
                            <td><?php echo $row['name']; ?></td>
                        </tr>
                        <tr>
                            <th>Class</th>
                            <td><?php echo $row['class_name']; ?></td>
                        </tr>
                        <tr>
                            <th>Created At</th>
                            <td><?php echo $row['created_at']; ?></td>
                        </tr>
                    </tbody>
                </table>

                <!-- Back Button -->
                <a href="view_students.php" class="btn btn-primary">Back to Student List</a>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS (Optional for interactivity) -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>

<?php
    } else {
        echo "<div class='container mt-5'><p class='alert alert-warning'>No student found with the provided ID.</p></div>";
    }
} else {
    echo "<div class='container mt-5'><p class='alert alert-danger'>No student ID provided.</p></div>";
}
?>
