<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $class_name = $_POST['class_name'];
    $sql = "INSERT INTO classes (name) VALUES ('$class_name')";
    if ($conn->query($sql) === TRUE) {
        $message = "Class added successfully!";
        $message_type = "success";
    } else {
        $message = "Error: " . $sql . "<br>" . $conn->error;
        $message_type = "error";
    }
}
?>
<?php include 'includes/header.php'; ?>
<main>
    <div class="form-container">
        <h2>Add Class</h2>
        
        <?php if (isset($message)): ?>
            <div class="message <?= $message_type; ?>"><?= $message; ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <label for="class_name">Class Name:</label>
            <input type="text" name="class_name" required>
            <button type="submit" class="btn">Add Class</button>
        </form>
    </div>
</main>
<?php include 'includes/footer.php'; ?>
