<?php include('includes/header.php'); ?>

<main>
    <div class="main-container">
        <h2 class="welcome-heading">Welcome to the <span class="highlight">Student Management System</span></h2>

    </div>
</main>

<?php include 'includes/footer.php'; ?>
