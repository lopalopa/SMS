<?php
include 'db.php';

// Check if the 'id' is provided in the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch the student details from the database
    $sql = "SELECT students.id, students.name, students.class_id, classes.id AS class_id, classes.name AS class_name 
            FROM students 
            JOIN classes ON students.class_id = classes.id
            WHERE students.id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Fetch the student record
        $row = $result->fetch_assoc();
    } else {
        echo "<p class='alert alert-warning'>No student found with the provided ID.</p>";
        exit();
    }
} else {
    echo "<p class='alert alert-danger'>No student ID provided.</p>";
    exit();
}

// Update student data if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $class_id = $_POST['class_id'];

    // Update the student record in the database
    $update_sql = "UPDATE students SET name = ?, class_id = ? WHERE id = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("sii", $name, $class_id, $id);

    if ($stmt->execute()) {
        echo "<div class='alert alert-success'>Student updated successfully.</div>";
        echo "<a href='view_students.php' class='btn btn-primary'>Back to Student List</a>";
    } else {
        echo "<div class='alert alert-danger'>Error updating student: " . $stmt->error . "</div>";
    }
}
?>

<!-- Edit Student Form -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4">Edit Student</h2>

        <!-- Edit Student Form -->
        <div class="card shadow-sm">
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label for="name" class="form-label">Name:</label>
                        <input type="text" name="name" value="<?php echo htmlspecialchars($row['name']); ?>" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label for="class_id" class="form-label">Class:</label>
                        <select name="class_id" class="form-select" required>
                            <?php
                            // Fetch all classes to populate the dropdown
                            $class_sql = "SELECT * FROM classes";
                            $class_result = $conn->query($class_sql);

                            while ($class = $class_result->fetch_assoc()) {
                                // Check if the current student is in this class
                                $selected = $row['class_id'] == $class['id'] ? 'selected' : '';
                                echo "<option value='{$class['id']}' $selected>{$class['name']}</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-success">Update Student</button>
                </form>

                <br>

                <!-- Back Button -->
                <a href="view_students.php" class="btn btn-secondary">Back to Student List</a>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS (Optional for interactivity) -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
