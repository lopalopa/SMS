<footer>
        <p>&copy; 2024 Student Management System</p>
    </footer>
</body>
</html>
