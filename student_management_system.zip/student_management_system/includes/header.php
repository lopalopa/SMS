<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Management System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Student Management System</h1>
        <nav>
            <a href="index.php">Home</a>
            <a href="add_class.php">Add Class</a>
            <a href="add_student.php">Add Student</a>
            <a href="view_students.php">View Students</a>
        </nav>
    </header>
