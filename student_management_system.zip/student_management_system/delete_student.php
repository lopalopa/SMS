<?php
include 'db.php';

// Check if 'id' is provided in the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch the student details to confirm before deleting
    $sql = "SELECT * FROM students WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Proceed to delete the student record
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $delete_sql = "DELETE FROM students WHERE id = $id";
            if ($conn->query($delete_sql) === TRUE) {
                echo "<p>Student deleted successfully.</p>";
                echo "<a href='view_students.php'>Back to Student List</a>";
            } else {
                echo "<p>Error deleting student: " . $conn->error . "</p>";
            }
        }
    } else {
        echo "<p>No student found with the provided ID.</p>";
    }
} else {
    echo "<p>No student ID provided.</p>";
}

?>

<!-- Delete Confirmation Form -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Student</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <div class="delete-student-form">
        <h2>Are you sure you want to delete this student?</h2>
        <form method="POST">
            <button type="submit">Yes, Delete</button>
        </form>
        <a href="view_students.php">Cancel</a>
    </div>
</body>
</html>
